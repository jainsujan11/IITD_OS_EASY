#include "types.h"
#include "user.h"

int main(void) {
  ps();
  exit();
}

