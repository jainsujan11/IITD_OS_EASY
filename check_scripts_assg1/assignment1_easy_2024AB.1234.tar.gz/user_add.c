#include "types.h"
#include "user.h"

int main(void) {
  int result = add(3, 5);
  printf(1, "3 + 5 = %d\n", result);
  exit();
}

