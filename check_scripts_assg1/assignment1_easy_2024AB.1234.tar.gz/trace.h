// trace.h
#ifndef TRACE_H
#define TRACE_H

extern int state;
extern int syscall_counts[];

#endif

